<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrainStation extends Model
{
    protected $fillable = ['station_name','code','city'];
}

@extends('errors::layout')

@section('title', 'Error')

@section('message', 'Whoops, sepertinya ada yang salah.')

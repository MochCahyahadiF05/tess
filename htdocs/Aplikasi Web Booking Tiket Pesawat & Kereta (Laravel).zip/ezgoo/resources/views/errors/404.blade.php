@extends('errors.layout')

@section('title', 'Page Not Found')

@section('message')
  Maaf, Halaman yang anda tuju tidak dapat ditemukan.<br>
<button class="btn btn-primary" id="goback" type="button" name="button">Kembali</button>
@stop

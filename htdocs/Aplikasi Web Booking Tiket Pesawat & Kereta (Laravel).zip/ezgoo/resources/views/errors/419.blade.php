@extends('errors::layout')

@section('title', 'Page Expired')

@section('message')
    Masa halaman ini telah habis karena tidak aktif.
    <br/><br/>
    Silahkan refresh dan coba lagi.
@stop

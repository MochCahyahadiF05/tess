@extends('errors::layout')

@section('title', 'Service sedang dalam perbaikan')

@section('message', 'Be right back.')

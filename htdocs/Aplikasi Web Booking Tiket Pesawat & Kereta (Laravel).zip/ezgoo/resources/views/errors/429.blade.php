@extends('errors::layout')

@section('title', 'Error')

@section('message', 'Terlalu banyak request.')

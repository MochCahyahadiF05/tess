<?php $__env->startSection('content'); ?>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.js"></script>
  <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
    <div class="row">
        <ol class="breadcrumb">
            <li><a href="#">
                <em class="fa fa-home"></em>
                </a></li>
            <li class="active">Booking</li>
        </ol>
      </div><br>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4>Grafik penjualan tiket tahun <?php echo e(date('Y')); ?></h4>
          </div>
          <div class="panel-body">
            <?php if(Session::has('alert-success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e(Session::get('alert-success')); ?></strong>
                </div>
            <?php endif; ?>
            <hr>
            <div style="width:75%;">
                <?php echo $chartjs->render(); ?>

            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
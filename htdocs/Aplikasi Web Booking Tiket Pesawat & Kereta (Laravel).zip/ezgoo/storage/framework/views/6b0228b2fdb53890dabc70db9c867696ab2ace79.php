<?php $__env->startSection('content'); ?>
<!--pilihan pesawat-->

<div class="container">
  <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h4>Dari <?php echo e($s->from); ?> ke <?php echo e($s->destination); ?> <p class="pull-right"><?php echo e(date('d-m-Y', strtotime($s->boarding_time))); ?></p> </h4>
    <?php if($s) break; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <form action="<?php echo e(url('booking/order')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="vehicle" value="<?php echo e($vehicle); ?>">
    <input type="hidden" name="total" value="<?php echo e(implode(',',$total)); ?>">
    <input type="hidden" name="seat" value="<?php echo e($seat); ?>">
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <?php if($vehicle == 'plane'): ?>
              <th>Pesawat</th>
              <th>Pergi</th>
              <th>Durasi</th>
              <th>Tiba</th>
              <th>Gate</th>
              <th>/orang</th>
            <?php elseif($vehicle == 'train'): ?>
              <th>Kereta</th>
              <th>Pergi</th>
              <th>Durasi</th>
              <th>Tiba</th>
              <th>Peron</th>
              <th>/orang</th>
            <?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php if($schedule->isEmpty()): ?>
            <td colspan="5">Maaf, jadwal dan rute yang dicari tidak ditemukan atau sudah penuh</td>
          <?php else: ?>
            <?php if($vehicle == 'plane'): ?>
              <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($s->plane_name); ?></td>
                  <?php
                    $duration = date('h',$s->duration);
                    $range    = strtotime($s->boarding_time ."+$duration hours");
                  ?>
                  <td><?php echo e(date('H:i:s', strtotime($s->boarding_time))); ?></td>
                  <td><?php echo e($duration); ?> jam</td>
                  <td><?php echo e(date('H:i:s', $range)); ?></td>
                  <td><?php echo e($s->gate); ?></td>
                  <td>IDR <?php echo e(number_format($s->$seat,2, ".", ",")); ?></td>
                  <td> <button type="submit" name="go" value="<?php echo e($s->id); ?>">Pesan</button></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php elseif($vehicle == 'train'): ?>
              <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($s->train_name); ?></td>
                  <?php
                    $duration = date('h',$s->duration);
                    $range    = strtotime($s->boarding_time ."+$duration hours");
                  ?>
                  <td><?php echo e(date('H:i:s', strtotime($s->boarding_time))); ?></td>
                  <td><?php echo e($duration); ?> jam</td>
                  <td><?php echo e(date('H:i:s', $range)); ?></td>
                  <td><?php echo e($s->duration); ?></td>
                  <td><?php echo e($s->platform); ?></td>
                  <td>IDR <?php echo e(number_format($s->$seat,2, ".", ",")); ?></td>
                  <td> <button type="submit" name="go" value="<?php echo e($s->id); ?>">Pesan</button></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
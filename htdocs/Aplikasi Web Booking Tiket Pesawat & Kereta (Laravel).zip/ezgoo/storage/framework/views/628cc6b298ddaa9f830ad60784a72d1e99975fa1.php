<?php $__env->startSection('title', 'Page Not Found'); ?>

<?php $__env->startSection('message'); ?>
  Maaf, Halaman yang anda tuju tidak dapat ditemukan.<br>
<button class="btn btn-primary" id="goback" type="button" name="button">Kembali</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>